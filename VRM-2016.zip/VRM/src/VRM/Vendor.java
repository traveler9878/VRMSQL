package VRM;

public class Vendor extends TrackerBase {
	private DataManager dmgr = null;
	private static final String TABLE_NAME = "vendors";
	
	public Vendor(DataManager dmgr) {
		super (dmgr, TABLE_NAME);
    }
	
	public Vendor ( DataManager dmgr, int ID ){
		super (dmgr, TABLE_NAME, ID);
	}
	
	
		
		
	
	public static void main(String[] args) {
		Vendor obj = new Vendor(new DataManager());
        //insert a new row
        obj.setContactInfo("contact info test");
        obj.setName("name test");
        obj.setRemarks("remarks test");
        obj.insertNewRow();
        //insert a new one way relationship
        //insert a new two way relationship
    }
}
