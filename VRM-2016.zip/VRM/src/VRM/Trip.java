package VRM;


public class Trip extends TrackerBase {
    public Trip() {
    }
}
