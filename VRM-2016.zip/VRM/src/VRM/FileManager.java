package VRM;

import java.io.*;

public class FileManager {

	BufferedReader bReader = null;
	BufferedWriter bWriter = null;
	PrintWriter pw = null;
	//String logFileName = "C:\\logs\\sql.log";
	String logFileName = "C:\\Users\\curtisd\\Documents\\logs\\sql.log";
	
public FileManager(){};

public void logSQL(String strSql){
	logSQL(logFileName, strSql);
}

public void logSQL(String strFilename, String strSql){
	try{
		pw = new PrintWriter(this.bWriter = new BufferedWriter(new FileWriter(strFilename, true)));
		pw.println(strSql);
	}catch(Exception e){
		e.printStackTrace();
	}finally{
		pw.close();
	}

}


	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
