package VRM;

import java.util.GregorianCalendar;

public class Meeting extends TrackerBase {

	private DataManager dmgr = null;
	private static final String TABLE_NAME = "meetings";
	
	public Meeting(DataManager dmgr) {
		super (dmgr, TABLE_NAME);
    }
	
	public Meeting ( DataManager dmgr, int ID ){
		super (dmgr, TABLE_NAME, ID);
	}
	
	
		
		
	
	public static void main(String[] args) {
        Meeting obj = new Meeting(new DataManager());
        //insert a new row
        obj.setContactInfo("contact info test");
        obj.setName("name test");
        obj.setRemarks("remarks test");
        obj.insertNewRow();
        //insert a new one way relationship
        //insert a new two way relationship
    }

}
