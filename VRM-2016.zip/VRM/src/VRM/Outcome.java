package VRM;

public class Outcome extends TrackerBase {
    public Outcome() {
    }
}
