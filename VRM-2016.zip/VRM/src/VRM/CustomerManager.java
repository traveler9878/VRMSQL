package VRM;

public class CustomerManager {

}
