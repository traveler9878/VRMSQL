package VRM;

import java.sql.*;
import com.mysql.jdbc.Driver;

public class DataManager {

private Connection conn = null;
private FileManager logger = null;
private String strSchema = "vrm";
private String strUser = "root";
private String strPassword = "finally?";

	
	public DataManager(){
		try {
			init();
		} catch ( Exception e ) {
			e.printStackTrace();
		}
	}
	
	public Connection getConn()
	{
		return this.conn;
	}
	
	public FileManager getLogger(){
		return this.logger;
	}
	
	public void init() {
		this.logger = new FileManager();
		try{
			Class.forName ( "com.mysql.jdbc.Driver" ).newInstance();
			Connection conn = DriverManager.getConnection ( "jdbc:mysql://localhost:3306/" + strSchema, 
					strUser, strPassword );
			this.conn = conn;
		}catch ( Exception e ){
			e.printStackTrace ();
		}
	}
	
	public void deleteRows(String strTableName, String strWhereClause){
		String strSql = "UPDATE  " + strSchema + "." + strTableName + " SET DELETED=now() " + strWhereClause;
		Statement stmt = null;
		try{
			stmt = this.conn.createStatement();
			this.logger.logSQL(strSql);
			stmt.execute(strSql);
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			stmt = null;
		}
	}
	
	public ResultSet getResultSet ( String strTableName, String strWhereClause ) {
		String strSql = "Select * from " + strSchema + "." 
				+ strTableName
				+ " " 
				+ strWhereClause
				+ " and deleted IS NULL"
				+ " Order By ID DESC";
		Statement stmt = null;
		ResultSet rs = null;
		
		try{
			stmt = this.conn.createStatement();
			this.logger.logSQL(strSql);
			rs = stmt.executeQuery(strSql);
			return rs;
		}catch (Exception e){
			e.printStackTrace();
		}
		stmt = null;
		return rs;
	}
	
	public ResultSet getResultSet ( String strTableName ) throws Exception {
		ResultSet returnRS = null;
		String strSql = "select * from " + strSchema + "." + strTableName + " Where deleted IS NULL Order By ID DESC";
		try {
			Statement stmt = this.conn.createStatement();
			this.logger.logSQL(strSql);
			returnRS = stmt.executeQuery (strSql);
		} catch ( Exception e ) {
			e.printStackTrace();
		}
		
		return returnRS;
	}
	
	public ResultSet getRelated ( String strTableName, int ID){
		return getRelated ( strTableName, ID, "R" );
	}
	
	public ResultSet getRelated ( String strTableName, int ID, String strRorL )
	{
		String strOppositeLetter = "";
		
		if ( strRorL.equalsIgnoreCase("R") ){
			strOppositeLetter = "L";
		}else if ( strRorL.equalsIgnoreCase("L") ){
			strOppositeLetter = "R";
		}else{
			//invalid character
			return null;
		}
		strRorL.toUpperCase();
		
		ResultSet returnRS = null;
		String strSql = "select trel.ID as 'Relation ID'"
				+ ", trel.NAME as 'Relation Name'"
				+ ", trel.L_TABLE_NAME as 'L_Table'"
				+ ", trel.R_TABLE_NAME as 'R_Table'"
				+ ", t.ID, t.NAME"
				+ " from " 
				+ strSchema 
				+ "."
				+ strTableName
				+ " t, " 
				+ strSchema 
				+ ".relationships trel"
				+ " where t.ID = trel." + strRorL + "_ID"
				+ " and trel." + strOppositeLetter + "_ID="
				+ ID
				+ " and trel.deleted is null";
		try {
			Statement stmt = this.conn.createStatement();
			this.logger.logSQL(strSql);
			returnRS = stmt.executeQuery (strSql);
		} catch ( Exception e ) {
			e.printStackTrace();
		}
		
		return returnRS;
	}
	
	
	public static void main ( String[] args ) {
		DataManager dataMgr = new DataManager();
		System.out.println( dataMgr.getConn() );
		
		try{
			ResultSet rset = dataMgr.getResultSet( "meetings" );
			while( rset.next() ){
				System.out.println( rset.getInt( "ID" ) );
			}
		}catch( Exception e ){
			e.printStackTrace();
		}
		
		dataMgr = null;
	}

	public int getNextID() {
		int retInt = 0;
		try{
			String strSql = "{call " + strSchema + ".sp_get_next_id()}";
			CallableStatement cStmt = this.conn.prepareCall(strSql);
			this.logger.logSQL(strSql);
			cStmt.execute();
			//get the next id, if it's not there let the error handling happen so 0 is not returned
			ResultSet rs = cStmt.getResultSet();
			rs.next();
			retInt = rs.getInt(1);
			rs.close();
			cStmt.close();
			
		}catch (Exception e){
			e.printStackTrace();
		}
		return retInt;
	}
}
