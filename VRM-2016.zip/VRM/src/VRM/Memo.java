package VRM;

public class Memo extends TrackerBase {
    public Memo() {
    }
}
