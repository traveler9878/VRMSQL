package VRM;

public class Committment extends TrackerBase {
    public Committment() {
    }
}
