package VRM;

public class Risk extends TrackerBase {
    public Risk() {
    }
}
