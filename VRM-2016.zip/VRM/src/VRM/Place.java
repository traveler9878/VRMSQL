package VRM;

import javax.swing.JPanel;

public class Place extends TrackerBase {
    public Place() {
    }
}
