package VRM;

public class Assignment extends TrackerBase {
    public Assignment() {
    }
}
