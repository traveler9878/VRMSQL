package VRM;

public class Mitigation extends TrackerBase {
    public Mitigation() {
    }
}
