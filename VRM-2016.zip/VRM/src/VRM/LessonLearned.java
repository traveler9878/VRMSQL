package VRM;

public class LessonLearned extends TrackerBase {
    public LessonLearned() {
    }
}
