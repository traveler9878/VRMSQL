package VRM;

public class Location extends TrackerBase {
    public Location() {
    }
}
