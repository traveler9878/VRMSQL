package VRM;

public class Type extends TrackerBase {
    public Type() {
    }
}
