package VRM;

import java.util.GregorianCalendar;

public class Person extends TrackerBase {
	private DataManager dmgr = null;
	private static final String TABLE_NAME = "people";
	
	public Person(DataManager dmgr) {
		super (dmgr, TABLE_NAME);
    }
	
	public Person ( DataManager dmgr, int ID ){
		this (dmgr);
		super.setID ( ID );
	}
    
	public static void main(String[] args) {
		Person obj = new Person(new DataManager());
        //insert a new row
        obj.setContactInfo("test");
        obj.setCreated(new GregorianCalendar());
        obj.setName("test name ");
        obj.setRemarks(" description");
        obj.insertNewRow();
        //insert a new one way relationship
        //insert a new two way relationship
    }

}
