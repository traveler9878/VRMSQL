package VRM;

public class Policy extends TrackerBase {
    public Policy() {
    }
}
