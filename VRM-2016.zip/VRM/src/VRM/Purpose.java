package VRM;

public class Purpose extends TrackerBase {
    public Purpose() {
    }
}
