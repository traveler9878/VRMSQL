package VRM;

public class Slide extends TrackerBase {
    public Slide() {
    }
}
