package VRM;

public class Subject extends TrackerBase {
    public Subject() {
    }
}
