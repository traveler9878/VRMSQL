package VRM;

public class Requirement extends TrackerBase {
    public Requirement() {
    }
}
