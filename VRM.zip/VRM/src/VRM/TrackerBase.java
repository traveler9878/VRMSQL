package VRM;

import java.util.*;
import java.sql.*;

public class TrackerBase {
    protected DataManager dmgr = null;
    protected String tableName = "";
    protected int ID = 0;
    protected String name = "";
    protected GregorianCalendar created = null;
    protected boolean deleted = false;
    protected boolean hidden = false;
    protected String remarks = "";
    protected String contactInfo = "";
    
    public TrackerBase ( DataManager dmgr, String strTableName, int ID ) {
        this(dmgr, strTableName);
        this.setID(ID);
        this.load();
    }
    
    public TrackerBase ( DataManager dmgr, String strTableName ) {
        super();
        if (dmgr == null){
        	dmgr = new DataManager();
        }
        this.dmgr = dmgr;
        this.tableName = strTableName;
    }
    
    public TrackerBase(String strTableName)
    {
    	this(null, strTableName);
    }
    
    public DataManager getDataManager(){
    	return this.dmgr;
    }
    
    public String getTableName(){
    	return this.tableName;
    }
    
    public int getID(){
    	return this.ID;
    }
    
    public String getName (){
    	return this.name;
    }
    
    public GregorianCalendar getCreated(){
    	return this.created;
    }
    
    public boolean isDeleted(){
    	return this.deleted;
    }
    
    public boolean isHidden(){
    	return this.hidden;
    }
    
    public String getRemarks(){
    	return this.remarks;
    }
    
    public String getContactInfo(){
    	return this.contactInfo;
    }
    
    public void setID(int id){
    	this.ID = id;
    }
    
    public void setName (String name){
    	this.name = name;
    }
    
    public void setCreated ( GregorianCalendar created ){
    	this.created = created;
    }
    
    public void setDeleted (boolean deleted){
    	this.deleted = deleted;
    }
    
    public void setHidden ( boolean hidden ){
    	this.hidden = hidden;
    }
    
    public void setRemarks ( String remarks ){
    	this.remarks = remarks;
    }
    
    public void setContactInfo ( String contactInfo ){
    	this.contactInfo = contactInfo;
    }
    
	public void insertNewRow(){
		Statement stmt = null;
		try{
			stmt = this.dmgr.getConn().createStatement();
				
			String strSql = "Insert into "
					+ this.getTableName()
					+ " (ID, NAME, REMARKS, CONTACT_INFO) values ("
					+ this.dmgr.getNextID()
					+ ", '" + this.getName()
					+ "', '" + this.getRemarks()
					+ "', '" + this.getContactInfo()
					+ "')";
			
			this.dmgr.getLogger().logSQL(strSql);
			
			stmt.executeUpdate(strSql);
			
		}catch (Exception e){
			e.printStackTrace();
		}
		
	}
	
	public void update(){
		Statement stmt = null;
		try{
			stmt = this.dmgr.getConn().createStatement();
			
			String strSql = "UPDATE "
					+ this.getTableName()
					+ " SET name='"
					+ this.getName()
					+ "', remarks='"
					+ this.getRemarks()
					+ "', contact_info='"
					+ this.getContactInfo()
					+ "' WHERE ID="
					+ this.getID();	
			
			this.dmgr.getLogger().logSQL(strSql);	
			
			stmt.executeUpdate(strSql);
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			stmt = null;
		}
	}

	public void persist(){
		this.update();
	}
	
	public void load(){
		ResultSet rs = null;
		try{
			String strSQL = "Where ID=" + ID;
			rs = this.dmgr.getResultSet(this.tableName, strSQL);
			if(rs.next()){
				this.setName(rs.getString("name"));
				this.setRemarks(rs.getString("remarks"));
				this.setContactInfo(rs.getString("contact_info"));
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			rs = null;
		}
	}

    public static void main(String[] args) {
        TrackerBase tb = new TrackerBase(new DataManager(), "meetings");
        //insert a new row
        tb.setContactInfo("harold.youra@alliancesol.net");
        tb.setCreated(new GregorianCalendar());
        tb.setName("Alliance ");
        tb.setRemarks("Discussed creating and maintaining a list of key personnel responsible for Exchange and Sharepoint upgrades and migrations to offer a Metalogix briefing. Discussed creation and manintenence of a list of personnel responsible for CDM rollout of the BAH award to offer Forescout briefing.");
        tb.insertNewRow();
        //insert a new one way relationship
        //insert a new two way relationship
    }

	
}
