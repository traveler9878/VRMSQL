package VRM;

public class Category extends TrackerBase {
    public Category() {
    }
}
