package VRM;

public class Note extends TrackerBase {
	private DataManager dmgr = null;
	private static final String TABLE_NAME = "vrm.notes";
	
	public Note(DataManager dmgr) {
		super (dmgr, TABLE_NAME);
    }
	
	public Note ( DataManager dmgr, int ID ){
		super (dmgr, TABLE_NAME, ID);
	}
	
	
		
		
	
	public static void main(String[] args) {
		Note obj = new Note(new DataManager());
        //insert a new row
        obj.setContactInfo("contact info test");
        obj.setName("name test");
        obj.setRemarks("remarks test");
        obj.insertNewRow();
        //insert a new one way relationship
        //insert a new two way relationship
    }
}
