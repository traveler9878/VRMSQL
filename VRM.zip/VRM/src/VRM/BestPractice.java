package VRM;

public class BestPractice extends TrackerBase {
    public BestPractice() {
    }
}
