package VRM;

public class Team extends TrackerBase {
    public Team() {
    }
}
