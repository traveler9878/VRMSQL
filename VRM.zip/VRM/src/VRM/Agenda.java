package VRM;

public class Agenda extends TrackerBase {
    public Agenda() {
    }
}
