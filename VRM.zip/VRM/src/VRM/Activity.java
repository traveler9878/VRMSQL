package VRM;

public class Activity extends TrackerBase {
    public Activity() {
    }
}
