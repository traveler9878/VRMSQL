package VRM;

public class Link extends TrackerBase {
    public Link() {
    }
}
