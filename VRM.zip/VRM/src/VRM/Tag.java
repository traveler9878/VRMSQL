package VRM;

public class Tag extends TrackerBase {
    public Tag() {
    }
}
