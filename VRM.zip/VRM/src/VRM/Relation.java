package VRM;

import java.sql.ResultSet;
import java.sql.Statement;

public class Relation extends TrackerBase {
	private DataManager dmgr = null;
	private static final String TABLE_NAME = "vrm.relationships";
	private int L_ID = 0;
	private int R_ID = 0;
	
	public Relation(DataManager dmgr) {
		super (dmgr, TABLE_NAME);
    }
	
	public Relation ( DataManager dmgr, int ID ){
		super (dmgr, TABLE_NAME, ID);
	}
	
	public void setL_ID ( int L_ID){
		this.L_ID = L_ID;
	}
	
	public void setL_ID ( String strL_ID ){
		this.L_ID = new Integer(strL_ID);
	}
	
	public void setR_ID ( int R_ID){
		this.R_ID = R_ID;
	}
	
	public void setR_ID ( String strR_ID ){
		this.R_ID =  new Integer(strR_ID);
	}
	
	public int getL_ID(){
		return this.L_ID;
	}
	
	public int getR_ID(){
		return this.R_ID;
	}
		
	public void insertNewRow(){
		Statement stmt = null;
		try{
			stmt = super.dmgr.getConn().createStatement();
				
			String strSql = "Insert into "
					+ this.getTableName()
					+ " (ID, NAME, REMARKS, CONTACT_INFO, L_ID, R_ID) values ("
					+ super.dmgr.getNextID()
					+ ", '" + super.getName()
					+ "', '" + super.getRemarks()
					+ "', '" + super.getContactInfo()
					+ "', " + this.getL_ID()
					+ ", " + this.getR_ID()
					+ ")";
			
			super.dmgr.getLogger().logSQL(strSql);
			
			stmt.executeUpdate(strSql);
			
		}catch (Exception e){
			e.printStackTrace();
		}
		
	}
	
	public void update(){
		Statement stmt = null;
		try{
			stmt = super.dmgr.getConn().createStatement();
			
			String strSql = "UPDATE "
					+ super.getTableName()
					+ " SET name='"
					+ super.getName()
					+ "', remarks='"
					+ super.getRemarks()
					+ "', contact_info='"
					+ super.getContactInfo()
					+ "', L_ID="
					+ this.getL_ID()
					+ ", R_ID="
					+ this.getR_ID()
					+ " WHERE ID="
					+ super.getID();	
			
			super.dmgr.getLogger().logSQL(strSql);	
			
			stmt.executeUpdate(strSql);
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			stmt = null;
		}
	}

	public void persist(){
		this.update();
	}
	
	public void load(){
		ResultSet rs = null;
		try{
			String strSQL = "Where ID=" + ID;
			rs = super.dmgr.getResultSet(super.tableName, strSQL);
			if(rs.next()){
				super.setName(rs.getString("name"));
				super.setRemarks(rs.getString("remarks"));
				super.setContactInfo(rs.getString("contact_info"));
				this.setL_ID(rs.getInt("L_ID"));
				this.setR_ID(rs.getInt("R_ID"));
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			rs = null;
		}
	}

	
	public static void main(String[] args) {
		Note obj = new Note(new DataManager());
        //insert a new row
        obj.setContactInfo("contact info test");
        obj.setName("name test");
        obj.setRemarks("remarks test");
        obj.insertNewRow();
        //insert a new one way relationship
        //insert a new two way relationship
    }
}
