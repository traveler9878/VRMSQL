package VRM;

public class Strategy extends TrackerBase {
    public Strategy() {
    }
}
