package VRM;

public class Deadline extends TrackerBase {
    public Deadline() {
    }
}
