package VRM;

public class MeetingManager {

	private DataManager dmgr = null;
	

	public MeetingManager ( DataManager dmgr ) {
		this.dmgr = dmgr;
	}	
	
	public void addMeeting ( Meeting meeting ){
		meeting.persist();
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
		
	

}
